

class Ast:

    def __init__(self, listaInstrucciones):
        self.listaInstrucciones = listaInstrucciones